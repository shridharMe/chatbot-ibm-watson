#!/bin/bash
# start the doai
cd /opt/doai/
sudo node bin/bot